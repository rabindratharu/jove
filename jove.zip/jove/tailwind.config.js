/** @type {import('tailwindcss').Config} */
export default {
  content: ["./**/*.php", "./**/*.{js,ts,jsx,tsx,html,php}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
