<?php
/**
 * Define custom functions for the theme.
 *
 * @package Jove
 */

// Define custom functions here.