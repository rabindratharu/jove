<?php
/**
 * Title: Homepage
 * Slug: jove/page-home
 * Description: A full page design for a Homepage
 * Categories: jove/pages
 * Keywords: page, layout, design, template, home
 * Viewport Width: 1500
 * Block Types: 
 * Post Types: 
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"jove/hero-text-image-and-logos"} /-->

<!-- wp:pattern {"slug":"jove/large-text-and-text-boxes"} /-->

<!-- wp:pattern {"slug":"jove/text-and-image-columns-with-icons"} /-->

<!-- wp:pattern {"slug":"jove/numbers"} /-->

<!-- wp:pattern {"slug":"jove/testimonials-and-logos"} /-->

<!-- wp:pattern {"slug":"jove/text-and-image-columns-with-testimonial"} /-->

<!-- wp:pattern {"slug":"jove/pricing-table"} /-->

<!-- wp:pattern {"slug":"jove/blog-post-columns"} /-->

<!-- wp:pattern {"slug":"jove/text-call-to-action"} /-->
