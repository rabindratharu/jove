<?php
/**
 * Title: Features Page
 * Slug: jove/page-features
 * Description: A full page design for a Features page
 * Categories: jove/pages, jove/features
 * Keywords: page, layout, design, template, features
 * Viewport Width: 1500
 * Block Types: 
 * Post Types: 
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"jove/card-text-and-call-to-action"} /-->

<!-- wp:pattern {"slug":"jove/feature-boxes"} /-->

<!-- wp:pattern {"slug":"jove/features-with-emojis"} /-->

<!-- wp:pattern {"slug":"jove/testimonial-highlight"} /-->
