<?php
/**
 * Title: Pricing Page
 * Slug: jove/page-pricing
 * Description: A full page design for a Pricing page
 * Categories: jove/pages, jove/pricing
 * Keywords: page, layout, design, template, pricing
 * Viewport Width: 1500
 * Block Types: 
 * Post Types: 
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"jove/pricing-table-with-testimonials"} /-->

<!-- wp:pattern {"slug":"jove/faq"} /-->

<!-- wp:pattern {"slug":"jove/numbers"} /-->
