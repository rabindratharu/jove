<?php
/**
 * Title: Blog Page
 * Slug: jove/blog-page
 * Description: A full page design for a blog page
 * Categories: jove/pages
 * Keywords: page, layout, design, template, blog, posts, query
 * Viewport Width: 1500
 * Block Types: 
 * Post Types: 
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"jove/post-loop-grid"} /-->
