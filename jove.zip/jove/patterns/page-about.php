<?php
/**
 * Title: About Page
 * Slug: jove/page-about
 * Description: A full page design for an About page
 * Categories: jove/pages
 * Keywords: page, layout, design, template
 * Viewport Width: 1500
 * Block Types: 
 * Post Types: 
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"jove/contact-details"} /-->

<!-- wp:pattern {"slug":"jove/team-members"} /-->

<!-- wp:pattern {"slug":"jove/numbers-stacked"} /-->

<!-- wp:pattern {"slug":"jove/job-openings"} /-->
