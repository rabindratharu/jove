<?php
/**
 * Title: Download Page
 * Slug: jove/page-download
 * Description: A full page design for a Download page
 * Categories: jove/pages
 * Keywords: page, layout, design, template, download
 * Viewport Width: 1500
 * Block Types: 
 * Post Types: 
 * Inserter: true
 */
?>
<!-- wp:pattern {"slug":"jove/text-and-details-card"} /-->

<!-- wp:pattern {"slug":"jove/faq"} /-->

<!-- wp:pattern {"slug":"jove/testimonials-with-social-links"} /-->

<!-- wp:pattern {"slug":"jove/image-and-numbered-features"} /-->

<!-- wp:pattern {"slug":"jove/text-call-to-action-buttons"} /-->
