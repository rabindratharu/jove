<?php
/**
 * Title: Breadcrumbs
 * Slug: jove/breadcrumbs
 * Description:
 * Categories: banner
 * Keywords: breadcrumbs, trail
 * Viewport Width: 1440
 * Block Types: x3p0/breadcrumbs
 * Post Types: wp_template
 * Inserter: true
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
    <!-- wp:x3p0/breadcrumbs /-->
</div>
<!-- /wp:group -->